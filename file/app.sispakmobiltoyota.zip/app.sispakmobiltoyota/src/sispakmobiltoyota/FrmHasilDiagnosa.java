/*
 =========================================================
 * Nama program : 
 * Keterangan	: Memuat hasil diagnosa
 * Nama Fie		: FrmHasilDiagnosa.java
 ========================================================
 */
package sispakmobiltoyota;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JScrollPane;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class FrmHasilDiagnosa extends JFrame {

	String identifikasi_terakhir = new String();
	private JPanel contentPane;
	private JLabel lblHipotesiYgAnda;
	private JTextField txtIdHslDiagKerusakan;
	private JTextField txtNmHslDiagKerusakan;
	private JTextField txtPerkiraan;
	private JLabel lblPilihan;
	private JTextField txtPilihanIdKerusakan;
	private JTextField txtPilihanNmKerusakan;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = { "Id_Gejala", "Gejala" };
	private JScrollPane scrTabelAlasan;
	private JTextField txtSolusi;
	private JLabel lblSolusi;
	private JLabel lblAlasannya;
	private JButton btnExit;
	private JButton btnKlik;
	private JButton btnUlang;

	/**
	 * Launch the application.
	 */
	
	  /*public static void main(String[] args) { EventQueue.invokeLater(new
	  Runnable() { public void run() { try { FrmHasilDiagnosa frame = new
			  FrmHasilDiagnosa(); frame.setVisible(true); } catch (Exception e) {
	  e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmHasilDiagnosa() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmHasilDiagnosa.class.getResource("/image/icon100x100.png")));
		setResizable(false);
		setTitle("Hasil Diagnosa");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				ambilSolusi();
				ambilTempAdaK();
				kondisi();
				tampilTabel();
				
				
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 623, 434);
		contentPane = new JPanel();
		contentPane.setBackground(Color.RED);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);

		lblHipotesiYgAnda = new JLabel("Hipotesis yg anda pilih :");
		lblHipotesiYgAnda.setForeground(new Color(255, 255, 255));
		lblHipotesiYgAnda.setBounds(26, 24, 174, 15);
		contentPane.add(lblHipotesiYgAnda);

		txtIdHslDiagKerusakan = new JTextField();
		txtIdHslDiagKerusakan.setEditable(false);
		txtIdHslDiagKerusakan.setBounds(26, 55, 114, 19);
		contentPane.add(txtIdHslDiagKerusakan);
		txtIdHslDiagKerusakan.setColumns(10);

		txtNmHslDiagKerusakan = new JTextField();
		txtNmHslDiagKerusakan.setEditable(false);
		txtNmHslDiagKerusakan.setColumns(10);
		txtNmHslDiagKerusakan.setBounds(152, 55, 438, 19);
		contentPane.add(txtNmHslDiagKerusakan);

		txtPerkiraan = new JTextField();
		txtPerkiraan.setEditable(false);
		txtPerkiraan.setColumns(10);
		txtPerkiraan.setBounds(26, 86, 329, 19);
		contentPane.add(txtPerkiraan);

		lblPilihan = new JLabel(
				"Karena berdasarkan hasil identifikasi yang anda pilih kerusakan terjadi pada :");
		lblPilihan.setForeground(new Color(255, 255, 255));
		lblPilihan.setBounds(26, 124, 564, 15);
		contentPane.add(lblPilihan);

		txtPilihanIdKerusakan = new JTextField();
		txtPilihanIdKerusakan.setEditable(false);
		txtPilihanIdKerusakan.setBounds(26, 151, 114, 19);
		contentPane.add(txtPilihanIdKerusakan);
		txtPilihanIdKerusakan.setColumns(10);

		txtPilihanNmKerusakan = new JTextField();
		txtPilihanNmKerusakan.setEditable(false);
		txtPilihanNmKerusakan.setColumns(10);
		txtPilihanNmKerusakan.setBounds(152, 151, 438, 19);
		contentPane.add(txtPilihanNmKerusakan);

		lblAlasannya = new JLabel("Alasannya");
		lblAlasannya.setForeground(new Color(255, 255, 255));
		lblAlasannya.setBounds(26, 182, 97, 15);
		contentPane.add(lblAlasannya);

		scrTabelAlasan = new JScrollPane();
		scrTabelAlasan.setBounds(120, 182, 473, 137);
		contentPane.add(scrTabelAlasan);

		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setModel(tabelModel);
		scrTabelAlasan.setViewportView(table);

		txtSolusi = new JTextField();
		txtSolusi.setEditable(false);
		txtSolusi.setBounds(120, 331, 473, 19);
		contentPane.add(txtSolusi);
		txtSolusi.setColumns(10);

		lblSolusi = new JLabel("Solusi");
		lblSolusi.setForeground(new Color(255, 255, 255));
		lblSolusi.setBounds(26, 333, 70, 15);
		contentPane.add(lblSolusi);

		btnExit = new JButton("Exit");
		btnExit.setForeground(Color.WHITE);
		btnExit.setBackground(new Color(51, 204, 255));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				hapusTemp();
			}
		});
		btnExit.setBounds(492, 362, 103, 25);
		contentPane.add(btnExit);

		btnUlang = new JButton("Ulangi Diagnosa");
		btnUlang.setBackground(new Color(51, 204, 255));
		btnUlang.setForeground(Color.WHITE);
		btnUlang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FrmPilihKerusakan().show();
				hapusTemp();
				dispose();
			}
		});
		btnUlang.setBounds(349, 362, 157, 25);
		contentPane.add(btnUlang);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 621, 12);
		contentPane.add(panel);

	}
	
	void ambilTempAdaK() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement st = (Statement) con.createStatement();
			String sql = "SELECT * FROM Temp WHERE IdGejala like 'K%' limit 1";
			ResultSet rs = (ResultSet) st.executeQuery(sql);
			while (rs.next()) {
				txtIdHslDiagKerusakan.setText(rs.getString("IdGejala"));
				txtNmHslDiagKerusakan.setText(rs.getString("NmGejala"));
			}
			rs.close();
			st.close();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "data tak teridentifikasi",
					"Pesan", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	void kondisi() {
		if (txtIdHslDiagKerusakan.getText().equals(
				txtPilihanIdKerusakan.getText())) {
			txtPerkiraan.setText("Pilihan anda benar");
		} else {
			txtPerkiraan.setText("Pilihan anda salah");
		}
	}

	void ambilSolusi() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement st = (Statement) con.createStatement();
			String sql = "SELECT Kerusakan.IdKerusakan, Kerusakan.NmKerusakan, Kerusakan.Solusi, Temp.IdGejala FROM Kerusakan, Temp, Target WHERE Temp.IdGejala = Target.IdGejala and Target.IdKerusakan = Kerusakan.IdKerusakan ORDER by IdGejala ASC";
			ResultSet rs = (ResultSet) st.executeQuery(sql);
			while (rs.next()) {
				txtPilihanIdKerusakan.setText(rs.getString("IdKerusakan"));
				txtPilihanNmKerusakan.setText(rs.getString("NmKerusakan"));
				txtSolusi.setText(rs.getString("Solusi"));
			}
			rs.close();
			st.close();

		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "data tak teridentifikasi",
					"Pesan", JOptionPane.INFORMATION_MESSAGE);
		}
	}


	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = (Statement) con.createStatement();
			// String query = "select * from Temp order by IdGejala desc";
			String query = "SELECT distinct * FROM Temp WHERE IdGejala not like 'K%'";
			ResultSet rs = (ResultSet) state.executeQuery(query);
			while (rs.next()) {

				Object obj[] = new Object[2];
				obj[0] = rs.getString(1);
				obj[1] = rs.getString(2);
				tabelModel.addRow(obj);
				sesuaikanKolom();
			}
			rs.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);
		}
	}

	void hapusTemp() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			String query = "Truncate Temp";
			PreparedStatement prepare = (PreparedStatement) con
					.prepareStatement(query);
			prepare.executeUpdate();
			// JOptionPane.showMessageDialog(null,"Data berhasil disimpan","Pesan",JOptionPane.INFORMATION_MESSAGE);
			prepare.close();

		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Data gagal disimpan", "Pesan",
					JOptionPane.ERROR_MESSAGE);
			System.out.println(ex);
		}
	}
}
