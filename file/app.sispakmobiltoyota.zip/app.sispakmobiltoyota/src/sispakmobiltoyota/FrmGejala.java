/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Gejala
 * Nama Fie		: FrmGejala.java
 ======================================================================= 
 */
package sispakmobiltoyota;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.SwingConstants;


import net.java.balloontip.BalloonTip;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class FrmGejala extends JFrame {

	String coba = new String();
	private JPanel contentPane;
	private JLabel lblIdGejala;
	private JLabel lblNmGejala;
	private JTextField txtIdGejala;
	private JButton btnKeluar;
	private JButton btnHapus;
	private JButton btnUbah;
	private JButton btnTambah;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = { "Id_Gejala", "Gejala" };
	private JTextArea txaGejala;
	private JTextField txtCari;
	private JLabel lblCari;
	private JButton btnCari;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	
	 /*public static void main(String[] args) { EventQueue.invokeLater(new
	  Runnable() { public void run() { try { FrmGejala frame = new FrmGejala();
	  frame.setVisible(true); } catch (Exception e) { e.printStackTrace(); } }
	  }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmGejala() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmGejala.class.getResource("/image/icon100x100.png")));
		setResizable(false);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 442);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.RED);
		panel.setBounds(0, -14, 505, 76);
		contentPane.add(panel);

		JLabel lblMasterPakar = new JLabel("Master Gejala");
		lblMasterPakar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMasterPakar.setForeground(Color.WHITE);
		lblMasterPakar
				.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblMasterPakar.setBounds(143, 31, 260, 29);
		panel.add(lblMasterPakar);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmGejala.class.getResource("/image/chrome-hmjkmjkepdijhoojdojkdfohbdgmmhki-Default.png")));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		label.setBounds(-55, 12, 142, 29);
		panel.add(label);

		lblIdGejala = new JLabel("Id Gejala :");
		lblIdGejala.setBounds(24, 104, 126, 15);
		contentPane.add(lblIdGejala);

		lblNmGejala = new JLabel("Gejala :");
		lblNmGejala.setBounds(24, 131, 104, 15);
		contentPane.add(lblNmGejala);
		
		
		txtIdGejala = new JTextField();
		txtIdGejala.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
			}
		});
		txtIdGejala.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				BalloonTip diagnosa = new BalloonTip(txtIdGejala, "IdGejala memuat huruf dan angka dan berjumlah 4 digit. Ex : A010");
			}
		});
		txtIdGejala.setBounds(149, 104, 114, 19);
		txtIdGejala.setDocument(new Setvalidator(4, true));
		contentPane.add(txtIdGejala);
		txtIdGejala.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setBounds(24, 203, 458, 112);
		contentPane.add(scrollPane);

		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setBackground(Color.WHITE);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				int pilih = table.getSelectedRow();
				if (pilih < 0) {
					return;
				}

				String username = (String) tabelModel.getValueAt(pilih, 0);
				txtIdGejala.setText(username);
				String password = (String) tabelModel.getValueAt(pilih, 1);
				txaGejala.setText(password);
				btnUbah.setEnabled(true);
				btnHapus.setEnabled(true);
				btnTambah.setEnabled(false);
				btnKeluar.setEnabled(false);
			}
		});
		table.setModel(tabelModel);
		scrollPane.setViewportView(table);

		btnTambah = new JButton("Tambah");
		btnTambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(txtIdGejala.getText().length() > 4){
					JOptionPane.showMessageDialog(null,"IdGejala yang di input lebih dari 4 digit","Ingat",JOptionPane.INFORMATION_MESSAGE);
					txtIdGejala.setText("");
					txtIdGejala.requestFocus();
						}
				else if(txtIdGejala.getText().length() < 4){
					JOptionPane.showMessageDialog(null,"IdGejala yang di input kurang dari 4 digit","Ingat",JOptionPane.INFORMATION_MESSAGE);
					txtIdGejala.setText("");
						}
				else if(txtIdGejala.getText().isEmpty()){
					JOptionPane.showMessageDialog(null,"IdGejala tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
					txtIdGejala.requestFocus();
				}else if(txaGejala.getText().isEmpty()){
					JOptionPane.showMessageDialog(null,"NamaGejala tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
					txaGejala.requestFocus();
					}
				else{
				try {
					
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "INSERT INTO Gejala VALUES(?,?)";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtIdGejala.getText());
					prepare.setString(2, txaGejala.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil ditambah", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					bersih();

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal ditambah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
					}
				}
			}	
		});
		btnTambah.setForeground(Color.WHITE);
		btnTambah.setBackground(Color.RED);
		btnTambah.setBounds(24, 373, 96, 25);
		contentPane.add(btnTambah);

		btnUbah = new JButton("Ubah");
		btnUbah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "UPDATE Gejala SET NmGejala  = ? WHERE IdGejala = ? ";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);
					prepare.setString(1, txaGejala.getText());
					prepare.setString(2, txtIdGejala.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data berhasil diubah",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					bersih();
					tampilTabel();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal diubah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
				}
			}
		});
		btnUbah.setForeground(Color.WHITE);
		btnUbah.setBackground(Color.RED);
		btnUbah.setEnabled(false);
		btnUbah.setBounds(122, 373, 96, 25);
		contentPane.add(btnUbah);

		btnHapus = new JButton("Hapus");
		btnHapus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "DELETE FROM Gejala WHERE IdGejala = ?";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtIdGejala.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil dihapus", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					bersih();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
				} catch (Exception ex) {
					System.out.println(ex);
					JOptionPane.showMessageDialog(null, "Data gagal diupdate",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnHapus.setForeground(Color.WHITE);
		btnHapus.setBackground(Color.RED);
		btnHapus.setEnabled(false);
		btnHapus.setBounds(217, 373, 104, 25);
		contentPane.add(btnHapus);

		btnKeluar = new JButton("Keluar");
		btnKeluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Keluar();
			}
		});
		btnKeluar.setForeground(Color.WHITE);
		btnKeluar.setBackground(Color.RED);
		btnKeluar.setBounds(386, 373, 96, 25);
		contentPane.add(btnKeluar);

		JScrollPane scrGejala = new JScrollPane();
		scrGejala.setBounds(147, 131, 335, 58);
		contentPane.add(scrGejala);

		txaGejala = new JTextArea();
		txaGejala.addKeyListener(new KeyAdapter() {
			/*@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!((c >= 'a') && (c <= 'z') && txaGejala.getText().length() < 100
				|| (c == KeyEvent.VK_BACK_SPACE)
				|| (c == KeyEvent.VK_DELETE))) {
				getToolkit().beep();
				e.consume();
				}

			}*/
		});
		scrGejala.setViewportView(txaGejala);
		//txaGejala.setDocument(new Setvalidator(150, true));
		
		lblCari = new JLabel("Cari Gejala :");
		lblCari.setBounds(24, 330, 126, 15);
		contentPane.add(lblCari);
		
		txtCari = new JTextField();
		txtCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cariGejala();
			}
		});
		txtCari.setColumns(10);
		txtCari.setBounds(149, 330, 289, 19);
		contentPane.add(txtCari);
		
		btnCari = new JButton("");
		btnCari.setIcon(new ImageIcon(FrmGejala.class.getResource("/image/system-search.png")));
		btnCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cariGejala();
			}
		});
		btnCari.setForeground(Color.WHITE);
		btnCari.setBackground(Color.BLACK);
		btnCari.setBounds(445, 327, 23, 23);
		contentPane.add(btnCari);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(0, 59, 505, 7);
		contentPane.add(panel_1);
		setLocationRelativeTo(null);

		tampilTabel();
	}

	void cariGejala(){
		try{
			/*Class.forName("com.mysql.jdbc.Driver").newInstance();	
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/sistempakar", "root", "root");*/
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String sql = "select * from Gejala where IdGejala like '%" + txtCari.getText()+ "%'" +
					"or NmGejala like '%" + txtCari.getText() + "%'";
			ResultSet rs = state.executeQuery(sql);
			while (rs.next()) {
			tabelModel.addRow(new Object[]{
			rs.getString(1),
			rs.getString(2)
			});
			}
			table.setModel(tabelModel);
			//tampilTabel();
			txtCari.setText("");
			}catch (Exception e){
				System.out.println(e);
			}
			}
	
	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String query = "SELECT * FROM Gejala where IdGejala not in('E310','E320') ";
			ResultSet rs = state.executeQuery(query);
			while (rs.next()) {

				Object obj[] = new Object[2];
				obj[0] = rs.getString(1);
				obj[1] = rs.getString(2);
				tabelModel.addRow(obj);
				sesuaikanKolom();
			}
			rs.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);
		}
	}

	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}
	
	void bersih(){
		txtIdGejala.setText("");
		txaGejala.setText("");
	}
	
	void batasinput(){
		int panjang=txtIdGejala.getText().length();
		if(panjang == 4){
		JOptionPane.showMessageDialog(null,"Kata yang di input panjangnya 5 karakter","Ingat",JOptionPane.INFORMATION_MESSAGE);
		txtIdGejala.setText("");
		}else{
		if(panjang<4){
		JOptionPane.showMessageDialog(null,"Jumlah karakter lebih kecil dari 5","Ingat",JOptionPane.INFORMATION_MESSAGE);
		txtIdGejala.setText("");
		}else{
		JOptionPane.showMessageDialog(null,"Jumlah karakter lebih besar dari 5","Ingat",JOptionPane.INFORMATION_MESSAGE);
		txtIdGejala.setText("");
		}
		}
	}
}
