-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 11, 2015 at 11:15 PM
-- Server version: 5.5.35-1
-- PHP Version: 5.5.9-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbsispaktoyota`
--

-- --------------------------------------------------------

--
-- Table structure for table `Gejala`
--

CREATE TABLE IF NOT EXISTS `Gejala` (
  `IdGejala` varchar(4) NOT NULL,
  `NmGejala` varchar(150) NOT NULL,
  PRIMARY KEY (`IdGejala`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Gejala`
--

INSERT INTO `Gejala` (`IdGejala`, `NmGejala`) VALUES
('A010', 'mesin mobil dapat dihidupkan'),
('A020', 'mesin mobil tidak dapat dihidupkan'),
('B010', 'kompresi mesin tidak stabil'),
('B020', 'sistem kemudi tidak berfungsi dengan baik'),
('B030', 'akselerasi mesin tidak sempurna'),
('B040', 'mesin mudah panas'),
('B050', 'kendaraan kurang stabil'),
('B060', 'sistem kelistrikan kecil'),
('B070', 'nyala api dibusi tidak konstan'),
('C010', 'perpindahan kecepatan terasa berat'),
('C020', 'sekring diperiksa sudah bagus'),
('C030', 'susah di stater'),
('C040', 'setelan ECU tidak sempurna'),
('C050', 'tarikan awal terasa berat'),
('C060', 'air radiator berkurang'),
('C070', 'akselerasi kendaraan berat'),
('C080', 'api dari coil ke busi tidak bagus'),
('C090', 'nyala api dibusi tidak konstan'),
('C100', 'pengapian dari coil ke CDI bagus'),
('C110', 'api di koil besar'),
('C120', 'api di coil ada tetapi kecil'),
('C130', 'waktu pengapian tidak baik'),
('D010', 'mengentak pada saat perpindahan kecepatan'),
('D020', 'kabel-kabel dari tombol relay ke lampu sudah diperiksa'),
('D030', 'mesin brebet'),
('D040', 'kompresi pada mesin tidak stabil'),
('D050', 'kekentalan oli berkurang'),
('D060', 'suara mesin kasar'),
('D070', 'oli sesuai standart kendaraan'),
('D080', 'tutup radiator bagus'),
('D090', 'sirkulasi air radiator kurang bagus'),
('D100', 'timbul bunyi pada kendaraan'),
('D110', 'ruang sistem kemudi tidak stabil'),
('D120', 'busi berwarna putih'),
('D130', 'pendistribusian api merata'),
('D140', 'tidak ada pengapian sama sekali'),
('D150', 'api di busi besar'),
('D160', 'api dibusi ada tetapi kecil'),
('D170', 'api dibusi berwarna merah'),
('E010', 'transmisi tidak mau pindah kecepatan'),
('E020', 'mobil tidak mau jalan saat di gas'),
('E030', 'terjadi kerenggangan antara kanvas dan plat kopling yang tidak sesuai'),
('E040', 'lampu dim tidak menyala'),
('E050', 'handle saklar rusak'),
('E060', 'pembakaran dibusi kurang konstan'),
('E070', 'suply bahan bakar tersendat-sendat'),
('E080', 'waktu CO tidak sesuai'),
('E090', 'sensor udara kotor'),
('E100', 'susah di starter pada pagi hari'),
('E110', 'oli berwarna hitam pekat'),
('E120', 'oli masuk ke ruang pembakaran'),
('E130', 'terjadi banyak gesekan dimesin'),
('E140', 'tekanan oli di mesin berkurang'),
('E150', 'air radiator tidak terjadi sirkulasi'),
('E160', 'selang radiator bocor'),
('E170', 'sirip pada radiator tidak berfungsi dengan baik'),
('E180', 'air tidak mengalir dengan baik pada radiator'),
('E190', 'balancing roda tidak pas'),
('E200', 'stang bearing longgar'),
('E210', 'posisi terod roda kurang pas'),
('E220', 'busi cepat mati'),
('E230', 'sistem ECU tidak stabil'),
('E240', 'terjadi short pada kabel CDI'),
('E250', 'bahan bakar tidak mau mengalir'),
('E260', 'busi tidak dapat memercikan api'),
('E270', 'areng busi sudah habis'),
('E280', 'nyala api dibusi tidak baik'),
('E290', 'pengapian tidak ada sama sekali'),
('E300', 'pelampung di injection rusak'),
('E310', 'tidak teridentifikasi'),
('E320', 'akhir ');

-- --------------------------------------------------------

--
-- Table structure for table `Kamus`
--

CREATE TABLE IF NOT EXISTS `Kamus` (
  `KdKamus` varchar(5) NOT NULL,
  `Kata` varchar(50) NOT NULL,
  `Keterangan` varchar(250) NOT NULL,
  PRIMARY KEY (`KdKamus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Kamus`
--

INSERT INTO `Kamus` (`KdKamus`, `Kata`, `Keterangan`) VALUES
('KM001', 'ECU', 'atau Electronic Control Unit berfungsi untuk mengatur sistem yang ada di mobil seperti pasokan udara, pasokan bahan bakar, kontrol kecepatan dan lain-lain');

-- --------------------------------------------------------

--
-- Table structure for table `Kerusakan`
--

CREATE TABLE IF NOT EXISTS `Kerusakan` (
  `IdKerusakan` varchar(4) NOT NULL,
  `NmKerusakan` varchar(250) NOT NULL,
  `Solusi` varchar(1000) NOT NULL,
  PRIMARY KEY (`IdKerusakan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Kerusakan`
--

INSERT INTO `Kerusakan` (`IdKerusakan`, `NmKerusakan`, `Solusi`) VALUES
('K010', 'gigi sinkronisasi rusak', 'ganti gigi sinkronisasi dengan yang baru'),
('K020', 'pegas diafragma patah', 'ganti pegas diafragma'),
('K030', 'plat kopling aus', 'lumas plat kopling'),
('K040', 'lampu dim putus', 'ganti lampu dim'),
('K050', 'per handle rusak', 'ganti per handle'),
('K060', 'kerenggangan pada busi tidak sesuai', 'atur kembali kerenggangan busi'),
('K070', 'filter bensin kotor', 'bersihkan filter bensin'),
('K080', 'sensor udara tersumbat', 'bersihkan sensor udara'),
('K090', 'filter udara kotor', 'bersihkan filter udara'),
('K100', 'sensor mata udara kotor	', 'bersihkan sensor mata udara'),
('K110', 'oli sudah tidak bagus', 'ganti oli'),
('K120', 'seat filter oli bocor	', 'ganti fiter oli dengan yang baru'),
('K130', 'oli tidak sesuai', 'ganti dengan oli yang sesuai'),
('K140', 'seal pompa air bocor	', 'ganti seal pompa oil dengan yang baru'),
('K150', 'seal pompa air rusak', 'ganti seal pompa air dengan yang baru'),
('K160', 'selang radiator rusak', 'ganti selang radiator dengan yang baru'),
('K170', 'sirip radiator tersumbat', 'bersihkan sirip radiator'),
('K180', 'pipa radiator kotor', 'bersihkan pipa radiator'),
('K190', 'stang arm bengkok', 'ganti stang arm'),
('K200', 'bearing tidak sesuai dengan roda', 'ganti dengan bearing yang sesuai'),
('K210', 'putaran beban rusak', 'ganti dengan putaran beban yang baru'),
('K220', 'titik mati atas tidak pas', 'atur TMA kembali'),
('K230', 'sistem ECU terjadi error', 'perbaiki sistem ECU'),
('K240', 'CDI rusak', 'ganti dengan CDI yang baru'),
('K250', 'bensin habis', 'beli bensin'),
('K260', 'kawat elektroda patah', 'ganti kawat elektroda'),
('K270', 'jarak areng dengan elektroda sudah renggang', 'atur kembali jarak elektroda dengan arang'),
('K280', 'sambungan kabel kelistrikan longgar', 'kencangkan kabel kelistrikan'),
('K290', 'busi tidak menyala dengan konstan', 'ganti dengan busi yang baru'),
('K300', 'pelampung bocor', 'ganti dengan pelampung yang baru');

-- --------------------------------------------------------

--
-- Table structure for table `Punya_Aturan_Tidak`
--

CREATE TABLE IF NOT EXISTS `Punya_Aturan_Tidak` (
  `IdAturanTidak` varchar(4) NOT NULL,
  `Satu` varchar(4) NOT NULL,
  `Dua` varchar(4) NOT NULL,
  PRIMARY KEY (`IdAturanTidak`),
  KEY `id_kesimpulan` (`Satu`),
  KEY `id_identifikasi` (`Dua`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Punya_Aturan_Tidak`
--

INSERT INTO `Punya_Aturan_Tidak` (`IdAturanTidak`, `Satu`, `Dua`) VALUES
('T001', 'E010', 'E020'),
('T002', 'E020', 'E030'),
('T003', 'E030', 'E310'),
('T004', 'E040', 'E050'),
('T005', 'E050', 'E310'),
('T006', 'E060', 'E070'),
('T007', 'E070', 'E310'),
('T008', 'E080', 'E090'),
('T009', 'E090', 'E100'),
('T010', 'E100', 'E310'),
('T011', 'E110', 'E310'),
('T012', 'E120', 'E130'),
('T013', 'E130', 'E310'),
('T014', 'E140', 'E310'),
('T015', 'E150', 'E160'),
('T016', 'E160', 'E310'),
('T017', 'E170', 'E180'),
('T018', 'E180', 'E310'),
('T019', 'E190', 'E200'),
('T020', 'E200', 'E310'),
('T021', 'E210', 'E310'),
('T022', 'E220', 'E310'),
('T023', 'E230', 'E310'),
('T024', 'E240', 'E250'),
('T025', 'E250', 'E310'),
('T026', 'E260', 'E270'),
('T027', 'E270', 'E310'),
('T028', 'E280', 'E310'),
('T029', 'E290', 'E300'),
('T030', 'E300', 'E310'),
('T031', 'D010', 'E320'),
('T032', 'D020', 'E320'),
('T033', 'D030', 'E320'),
('T034', 'D040', 'E320'),
('T035', 'D050', 'D060'),
('T036', 'D060', 'D070'),
('T037', 'D070', 'E320'),
('T038', 'D080', 'D090'),
('T039', 'D090', 'E320'),
('T040', 'D100', 'D110'),
('T041', 'D110', 'E320'),
('T042', 'D120', 'E320'),
('T043', 'D130', 'E320'),
('T044', 'D140', 'E320'),
('T045', 'D150', 'E320'),
('T046', 'D160', 'E320'),
('T047', 'D170', 'E320'),
('T048', 'C010', 'E320'),
('T049', 'C020', 'E320'),
('T050', 'C030', 'C040'),
('T051', 'C040', 'C050'),
('T052', 'C050', 'E320'),
('T053', 'C060', 'E320'),
('T054', 'C070', 'E320'),
('T055', 'C080', 'C090'),
('T056', 'C090', 'C100'),
('T057', 'C100', 'C110'),
('T058', 'C110', 'C120'),
('T059', 'C120', 'E320'),
('T060', 'C130', 'E320'),
('T061', 'B010', 'B020'),
('T062', 'B020', 'B030'),
('T063', 'B030', 'B040'),
('T064', 'B040', 'B050'),
('T065', 'B050', 'E320'),
('T066', 'B060', 'B070'),
('T067', 'B070', 'E320'),
('T068', 'A010', 'E320'),
('T069', 'A020', 'E320');

-- --------------------------------------------------------

--
-- Table structure for table `Punya_Aturan_Ya`
--

CREATE TABLE IF NOT EXISTS `Punya_Aturan_Ya` (
  `IdAturanYa` varchar(4) NOT NULL,
  `Satu` varchar(4) NOT NULL,
  `Dua` varchar(4) NOT NULL,
  PRIMARY KEY (`IdAturanYa`),
  KEY `id_kesimpulan` (`Satu`),
  KEY `id_identifikasi` (`Dua`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Punya_Aturan_Ya`
--

INSERT INTO `Punya_Aturan_Ya` (`IdAturanYa`, `Satu`, `Dua`) VALUES
('Y001', 'E010', 'D010'),
('Y002', 'D010', 'C010'),
('Y003', 'C010', 'B010'),
('Y004', 'B010', 'A010'),
('Y005', 'E020', 'D010'),
('Y006', 'E030', 'D010'),
('Y007', 'E040', 'D020'),
('Y008', 'D020', 'C020'),
('Y009', 'C020', 'B020'),
('Y010', 'B020', 'A010'),
('Y011', 'E050', 'D020'),
('Y012', 'E060', 'D030'),
('Y013', 'D030', 'C030'),
('Y014', 'C030', 'B030'),
('Y015', 'B030', 'A010'),
('Y016', 'E070', 'D030'),
('Y017', 'E080', 'D040'),
('Y018', 'D040', 'C040'),
('Y019', 'C040', 'B030'),
('Y020', 'E090', 'D040'),
('Y021', 'E100', 'D040'),
('Y022', 'E110', 'D050'),
('Y023', 'D050', 'C050'),
('Y024', 'C050', 'B030'),
('Y025', 'E120', 'D060'),
('Y026', 'D060', 'C050'),
('Y027', 'E130', 'D060'),
('Y028', 'E140', 'D070'),
('Y029', 'D070', 'C050'),
('Y030', 'E150', 'D080'),
('Y031', 'D080', 'C060'),
('Y032', 'C060', 'B040'),
('Y033', 'B040', 'A010'),
('Y034', 'E160', 'D080'),
('Y035', 'E170', 'D090'),
('Y036', 'D090', 'C060'),
('Y037', 'E180', 'D090'),
('Y038', 'E190', 'D100'),
('Y039', 'D100', 'C070'),
('Y040', 'C070', 'B050'),
('Y041', 'B050', 'A010'),
('Y042', 'E200', 'D100'),
('Y043', 'E210', 'D110'),
('Y044', 'D110', 'C070'),
('Y045', 'E220', 'D120'),
('Y046', 'D120', 'C080'),
('Y047', 'C080', 'B060'),
('Y048', 'B060', 'A020'),
('Y049', 'E230', 'D130'),
('Y050', 'D130', 'C090'),
('Y051', 'C090', 'B060'),
('Y052', 'E240', 'D140'),
('Y053', 'D140', 'C100'),
('Y054', 'C100', 'B060'),
('Y055', 'E250', 'D140'),
('Y056', 'E260', 'D150'),
('Y057', 'D150', 'C110'),
('Y058', 'C110', 'B060'),
('Y059', 'E270', 'D150'),
('Y060', 'E280', 'D160'),
('Y061', 'D160', 'C120'),
('Y062', 'C120', 'B060'),
('Y063', 'E290', 'D170'),
('Y064', 'D170', 'C130'),
('Y065', 'C130', 'B070'),
('Y066', 'B070', 'A020'),
('Y067', 'E300', 'D170');

-- --------------------------------------------------------

--
-- Table structure for table `Target`
--

CREATE TABLE IF NOT EXISTS `Target` (
  `IdTarget` varchar(5) NOT NULL,
  `IdKerusakan` varchar(4) NOT NULL,
  `IdGejala` varchar(4) NOT NULL,
  PRIMARY KEY (`IdTarget`),
  KEY `id_identifikasi` (`IdGejala`),
  KEY `id_kesimpulan` (`IdKerusakan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Target`
--

INSERT INTO `Target` (`IdTarget`, `IdKerusakan`, `IdGejala`) VALUES
('TG001', 'K010', 'A010'),
('TG002', 'K010', 'B010'),
('TG003', 'K010', 'C010'),
('TG004', 'K010', 'D010'),
('TG005', 'K010', 'E010'),
('TG006', 'K020', 'A010'),
('TG007', 'K020', 'B010'),
('TG008', 'K020', 'C010'),
('TG009', 'K020', 'D010'),
('TG010', 'K020', 'E020'),
('TG011', 'K030', 'A010'),
('TG012', 'K030', 'B010'),
('TG013', 'K030', 'C010'),
('TG014', 'K030', 'D010'),
('TG015', 'K030', 'E030'),
('TG016', 'K040', 'A010'),
('TG017', 'K040', 'B020'),
('TG018', 'K040', 'C020'),
('TG019', 'K040', 'D020'),
('TG020', 'K040', 'E040'),
('TG021', 'K050', 'A010'),
('TG022', 'K050', 'B020'),
('TG023', 'K050', 'C020'),
('TG024', 'K050', 'D020'),
('TG025', 'K050', 'E050'),
('TG026', 'K060', 'A010'),
('TG027', 'K060', 'B030'),
('TG028', 'K060', 'C030'),
('TG029', 'K060', 'D030'),
('TG030', 'K060', 'E060'),
('TG031', 'K070', 'A010'),
('TG032', 'K070', 'B030'),
('TG033', 'K070', 'C030'),
('TG034', 'K070', 'D030'),
('TG035', 'K070', 'E070'),
('TG036', 'K080', 'A010'),
('TG037', 'K080', 'B030'),
('TG038', 'K080', 'C040'),
('TG039', 'K080', 'D040'),
('TG040', 'K080', 'E080'),
('TG041', 'K090', 'A010'),
('TG042', 'K090', 'B030'),
('TG043', 'K090', 'C040'),
('TG044', 'K090', 'D040'),
('TG045', 'K090', 'E090'),
('TG046', 'K100', 'A010'),
('TG047', 'K100', 'B030'),
('TG048', 'K100', 'C040'),
('TG049', 'K100', 'D040'),
('TG050', 'K100', 'E100'),
('TG051', 'K110', 'A010'),
('TG052', 'K110', 'B030'),
('TG053', 'K110', 'C050'),
('TG054', 'K110', 'D050'),
('TG055', 'K110', 'E110'),
('TG056', 'K120', 'A010'),
('TG057', 'K120', 'B030'),
('TG058', 'K120', 'C050'),
('TG059', 'K120', 'D060'),
('TG060', 'K120', 'E120'),
('TG061', 'K130', 'A010'),
('TG062', 'K130', 'B030'),
('TG063', 'K130', 'C050'),
('TG064', 'K130', 'D060'),
('TG065', 'K130', 'E130'),
('TG066', 'K140', 'A010'),
('TG067', 'K140', 'B030'),
('TG068', 'K140', 'C050'),
('TG069', 'K140', 'D070'),
('TG070', 'K140', 'E140'),
('TG071', 'K150', 'A010'),
('TG072', 'K150', 'B040'),
('TG073', 'K150', 'C060'),
('TG074', 'K150', 'D080'),
('TG075', 'K150', 'E150'),
('TG076', 'K160', 'A010'),
('TG077', 'K160', 'B040'),
('TG078', 'K160', 'C060'),
('TG079', 'K160', 'D080'),
('TG080', 'K160', 'E160'),
('TG081', 'K170', 'A010'),
('TG082', 'K170', 'B040'),
('TG083', 'K170', 'C060'),
('TG084', 'K170', 'D090'),
('TG085', 'K170', 'E170'),
('TG086', 'K180', 'A010'),
('TG087', 'K180', 'B040'),
('TG088', 'K180', 'C060'),
('TG089', 'K180', 'D090'),
('TG090', 'K180', 'E180'),
('TG091', 'K190', 'A010'),
('TG092', 'K190', 'B050'),
('TG093', 'K190', 'C070'),
('TG094', 'K190', 'D100'),
('TG095', 'K190', 'E190'),
('TG096', 'K200', 'A010'),
('TG097', 'K200', 'B050'),
('TG098', 'K200', 'C070'),
('TG099', 'K200', 'D100'),
('TG100', 'K200', 'E200'),
('TG101', 'K210', 'A010'),
('TG102', 'K210', 'B050'),
('TG103', 'K210', 'C070'),
('TG104', 'K210', 'D110'),
('TG105', 'K210', 'E210'),
('TG106', 'K220', 'A020'),
('TG107', 'K220', 'B060'),
('TG108', 'K220', 'C080'),
('TG109', 'K220', 'D120'),
('TG110', 'K220', 'E220'),
('TG111', 'K230', 'A020'),
('TG112', 'K230', 'B060'),
('TG113', 'K230', 'C090'),
('TG114', 'K230', 'D130'),
('TG115', 'K230', 'E230'),
('TG116', 'K240', 'A020'),
('TG117', 'K240', 'B060'),
('TG118', 'K240', 'C100'),
('TG119', 'K240', 'D140'),
('TG120', 'K240', 'E240'),
('TG121', 'K250', 'A020'),
('TG122', 'K250', 'B060'),
('TG123', 'K250', 'C100'),
('TG124', 'K250', 'D140'),
('TG125', 'K250', 'E250'),
('TG126', 'K260', 'A020'),
('TG127', 'K260', 'B060'),
('TG128', 'K260', 'C110'),
('TG129', 'K260', 'D150'),
('TG130', 'K260', 'E260'),
('TG131', 'K270', 'A020'),
('TG132', 'K270', 'B060'),
('TG133', 'K270', 'C110'),
('TG134', 'K270', 'D150'),
('TG135', 'K270', 'E270'),
('TG136', 'K280', 'A020'),
('TG137', 'K280', 'B060'),
('TG138', 'K280', 'C120'),
('TG139', 'K280', 'D160'),
('TG140', 'K280', 'E280'),
('TG141', 'K290', 'A020'),
('TG142', 'K290', 'B070'),
('TG143', 'K290', 'C130'),
('TG144', 'K290', 'D170'),
('TG145', 'K290', 'E290'),
('TG146', 'K300', 'A020'),
('TG147', 'K300', 'B070'),
('TG148', 'K300', 'C130'),
('TG149', 'K300', 'D170'),
('TG150', 'K300', 'E300');

-- --------------------------------------------------------

--
-- Table structure for table `Temp`
--

CREATE TABLE IF NOT EXISTS `Temp` (
  `IdGejala` varchar(4) NOT NULL,
  `NmGejala` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `Id` int(2) NOT NULL AUTO_INCREMENT,
  `Username` varchar(8) NOT NULL,
  `Password` varchar(8) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`Id`, `Username`, `Password`) VALUES
(1, 'pakar', 'pakar');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Target`
--
ALTER TABLE `Target`
  ADD CONSTRAINT `Target_ibfk_1` FOREIGN KEY (`IdKerusakan`) REFERENCES `Kerusakan` (`IdKerusakan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Target_ibfk_2` FOREIGN KEY (`IdGejala`) REFERENCES `Gejala` (`IdGejala`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
