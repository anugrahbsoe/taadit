/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Arahan
 * Nama Fie		: FrmArahan.java
 ======================================================================= 
 */
package sispakmobiltoyota;

import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.JScrollPane;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JTable;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.border.LineBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.Toolkit;

public class FrmArahan extends JFrame {

	private JPanel contentPane;
	private JPanel panel;
	private JScrollPane scrollPane;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = {"IdKerusakan", "NmKerusakan","IdGejala","NmGejala"};
	private JLabel lblId;
	private JButton btnTutup;
	private JButton btnUlang;
	private JLabel lblArahan;
	private JPanel panel_1;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmArahan frame = new FrmArahan();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public FrmArahan() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmArahan.class.getResource("/image/icon100x100.png")));
		setResizable(false);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				tampilTabel();
			}
			@Override
			public void windowClosed(WindowEvent e) {
				hapusTemp();
			}
			@Override
			public void windowClosing(WindowEvent e) {
				hapusTemp();
			}
		});
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 574, 340);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 83, 548, 165);
		contentPane.add(scrollPane);
		
		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setBackground(Color.WHITE);
		table.setModel(tabelModel);
		scrollPane.setViewportView(table);
		
		panel = new JPanel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 572, 39);
		contentPane.add(panel);
		panel.setLayout(null);
		
		lblArahan = new JLabel("--Arahan--");
		lblArahan.setForeground(Color.WHITE);
		lblArahan.setBounds(264, 12, 97, 15);
		panel.add(lblArahan);
		
		lblId = new JLabel("");
		lblId.setVisible(false);
		lblId.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblId.setBounds(12, 277, 91, 19);
		contentPane.add(lblId);
		
		btnTutup = new JButton("Tutup");
		btnTutup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				//new FrmMenuPemakai().show();
			}
		});
		btnTutup.setForeground(Color.WHITE);
		btnTutup.setBackground(Color.RED);
		btnTutup.setBounds(311, 271, 117, 25);
		contentPane.add(btnTutup);
		
		btnUlang = new JButton("Ulangi Diagnosa");
		btnUlang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new FrmPilihKerusakan().show();
				dispose();
			}
		});
		btnUlang.setForeground(Color.WHITE);
		btnUlang.setBackground(Color.RED);
		btnUlang.setBounds(154, 271, 161, 25);
		contentPane.add(btnUlang);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(0, 38, 572, 10);
		contentPane.add(panel_1);
	}
	
	public JLabel IdKerusakan(){
		return lblId;
	}
	
	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = (Statement) con.createStatement();
			String query = "select distinct Target.IdKerusakan,Kerusakan.NmKerusakan from Target,Kerusakan where Kerusakan.IdKerusakan = Target.IdKerusakan and Target.IdGejala='"+lblId.getText()+"'";
			ResultSet rs = (ResultSet) state.executeQuery(query);
			while (rs.next()) {

				// Query didalam query; untuk menampilkan gejala
				Statement state1 = (Statement) con.createStatement();
				String jalary = "select Kerusakan.IdKerusakan,Kerusakan.NmKerusakan,Gejala.IdGejala ,Gejala.NmGejala from Target,Gejala,Kerusakan where Target.IdKerusakan = '"+ rs.getString(1) +"' and Gejala.IdGejala > '"+ lblId.getText() +"' and Gejala.IdGejala = Target.IdGejala and Target.IdKerusakan = Kerusakan.IdKerusakan";
				ResultSet rs1 = (ResultSet) state1.executeQuery(jalary);
				while(rs1.next()){
					Object obj[] = new Object[4];
					obj[0] = rs1.getString(1);
					obj[1] = rs1.getString(2);
					obj[2] = rs1.getString(3);
					obj[3] = rs1.getString(4);
					tabelModel.addRow(obj);
					sesuaikanKolom();
				}
				rs1.close();
				state1.close();
				// ------------------
				
				//Object obj[] = new Object[2];
				//obj[0] = rs.getString(1);
				//obj[1] = rs.getString(2);
				//tabelModel.addRow(obj);
				//sesuaikanKolom();
			}
			rs.close();
			//rs1.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);

		}
	}
	
	
	void hapusTemp() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			String query = "Truncate Temp";
			PreparedStatement prepare = (PreparedStatement) con
					.prepareStatement(query);
			prepare.executeUpdate();
			// JOptionPane.showMessageDialog(null,"Data berhasil disimpan","Pesan",JOptionPane.INFORMATION_MESSAGE);
			prepare.close();

		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Data gagal disimpan", "Pesan",
					JOptionPane.ERROR_MESSAGE);
			System.out.println(ex);
		}
	}
}
