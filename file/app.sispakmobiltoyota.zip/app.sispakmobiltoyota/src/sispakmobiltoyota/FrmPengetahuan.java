/*
 * Nama program : 
 * Keterangan	: Memuat menu pengetahuan
 * Nama Fie		: Pengetahuan.java
 */
package sispakmobiltoyota;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import IconMakeOver.IconLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Toolkit;

public class FrmPengetahuan extends JFrame {

	private JPanel contentPane;
	private IconLabel cnlblMasterGejala;
	private IconLabel cnlblMasterKerusakan;
	private IconLabel cnlblBasisAturan;
	private JLabel lblBack;

	/**
	 * Launch the application.
	 */
	/*
	 * public static void main(String[] args) { EventQueue.invokeLater(new
	 * Runnable() { public void run() { try { FrmPengetahuan frame = new
	 * FrmPengetahuan(); frame.setVisible(true); } catch (Exception e) {
	 * e.printStackTrace(); } } }); }
	 */

	/**
	 * Create the frame.
	 */
	public FrmPengetahuan() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmPengetahuan.class.getResource("/image/icon100x100.png")));
		setResizable(false);
		setTitle("Pengetahuan");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.RED);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		cnlblMasterGejala = new IconLabel();
		cnlblMasterGejala.setForeground(new Color(255, 255, 255));
		cnlblMasterGejala.setHorizontalAlignment(SwingConstants.TRAILING);
		cnlblMasterGejala.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmGejala frame = new FrmGejala();
				frame.show();
			}
		});
		cnlblMasterGejala.setIcon(new ImageIcon(FrmPengetahuan.class.getResource("/image/chrome-hmjkmjkepdijhoojdojkdfohbdgmmhki-Default.png")));
		cnlblMasterGejala.setText("Master Gejala");
		cnlblMasterGejala.setBounds(30, 36, 139, 143);
		contentPane.add(cnlblMasterGejala);

		cnlblMasterKerusakan = new IconLabel();
		cnlblMasterKerusakan.setForeground(new Color(255, 255, 255));
		cnlblMasterKerusakan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmKerusakan frame = new FrmKerusakan();
				frame.show();
			}
		});
		cnlblMasterKerusakan.setIcon(new ImageIcon(FrmPengetahuan.class.getResource("/image/activity-log-manager.png")));
		cnlblMasterKerusakan.setText("Master Kerusakan");
		cnlblMasterKerusakan.setHorizontalAlignment(SwingConstants.CENTER);
		cnlblMasterKerusakan.setBounds(192, 36, 139, 143);
		contentPane.add(cnlblMasterKerusakan);

		cnlblBasisAturan = new IconLabel();
		cnlblBasisAturan.setForeground(new Color(255, 255, 255));
		cnlblBasisAturan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmBasisAturan frame = new FrmBasisAturan();
				frame.show();
			}
		});
		cnlblBasisAturan.setIcon(new ImageIcon(FrmPengetahuan.class.getResource("/image/unity-tweak-tool.png")));
		cnlblBasisAturan.setText("Basis Aturan");
		cnlblBasisAturan.setHorizontalAlignment(SwingConstants.CENTER);
		cnlblBasisAturan.setBounds(330, 36, 139, 143);
		contentPane.add(cnlblBasisAturan);

		lblBack = new JLabel("");
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		lblBack.setIcon(new ImageIcon(FrmPengetahuan.class.getResource("/image/converseen.png")));
		lblBack.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		lblBack.setBounds(237, 206, 39, 36);
		contentPane.add(lblBack);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 499, 10);
		contentPane.add(panel);
		setLocationRelativeTo(null);
	}
}
