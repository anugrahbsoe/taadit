/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Aturan Tidak
 * Nama Fie		: FrmAturanTidak.java
 ======================================================================= 
 */
package sispakmobiltoyota;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class FrmAturanTidak extends JFrame {

	private JPanel contentPane;
	private JLabel lblIdGejala2;
	private JButton btnKeluar;
	private JButton btnHapus;
	private JButton btnUbah;
	private JButton btnTambah;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = { "IdAturanTidak", "IdGejala1", "IdGejala2" };
	private JLabel lblIdGejala1;
	private JTextField txtNmGejala1;
	private JTextField txtNmGejala2;
	private JLabel lblNmGejala;
	private JLabel lblNmGejala2;
	private JComboBox cmbIdGejala1;
	private JComboBox cmbIdGejala2;
	private JTextField txtAturanYa;
	private JLabel IdAturanTidak;
	private JLabel lblAturanYa;
	private JPanel panel;
	private JLabel lblCari;
	private JTextField txtCari;
	private JButton btnCari;
	private JPanel panel_1;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	
	 /*public static void main(String[] args) { EventQueue.invokeLater(new
	 Runnable() { public void run() { try { FrmAturanTidak frame = new
	 FrmAturanTidak(); frame.setVisible(true); } catch (Exception e) {
	 e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmAturanTidak() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmAturanTidak.class.getResource("/image/icon100x100.png")));
		setResizable(false);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 547, 471);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.RED);
		panel.setBounds(0, -14, 547, 80);
		contentPane.add(panel);

		lblAturanYa = new JLabel("Aturan Tidak");
		lblAturanYa.setForeground(Color.WHITE);
		lblAturanYa.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblAturanYa.setBounds(233, 30, 134, 29);
		panel.add(lblAturanYa);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmAturanTidak.class.getResource("/image/preferences-system.png")));
		label.setForeground(Color.WHITE);
		label.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		label.setBounds(-18, 12, 66, 68);
		panel.add(label);

		lblIdGejala2 = new JLabel("Id Gejala 2 :");
		lblIdGejala2.setBounds(24, 154, 126, 15);
		contentPane.add(lblIdGejala2);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setBounds(24, 185, 515, 171);
		contentPane.add(scrollPane);

		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setBackground(Color.WHITE);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				int pilih = table.getSelectedRow();
				if (pilih < 0) {
					return;
				}

				String no = (String) tabelModel.getValueAt(pilih, 0);
				txtAturanYa.setText(no);
				String gejala1 = (String) tabelModel.getValueAt(pilih, 1);
				cmbIdGejala1.setSelectedItem(gejala1);
				String gejala2 = (String) tabelModel.getValueAt(pilih, 2);
				cmbIdGejala2.setSelectedItem(gejala2);
				btnUbah.setEnabled(true);
				btnHapus.setEnabled(true);
				btnTambah.setEnabled(false);
				btnKeluar.setEnabled(false);
			}
		});
		table.setModel(tabelModel);
		scrollPane.setViewportView(table);

		btnTambah = new JButton("Tambah");
		btnTambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (cmbIdGejala1.getSelectedIndex() == 0) {
					JOptionPane.showMessageDialog(null,
							"Pilih salah satu gejala", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				}else if(cmbIdGejala2.getSelectedIndex() == 0) {
					JOptionPane.showMessageDialog(null,
							"Pilih salah satu gejala", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					
				}else{
					try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "INSERT INTO Punya_Aturan_Tidak VALUES(?,?,?)";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtAturanYa.getText());
					prepare.setString(2,
							(String) cmbIdGejala1.getSelectedItem());
					prepare.setString(3,
							(String) cmbIdGejala2.getSelectedItem());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil ditambah", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					autoNomer("Punya_Aturan_Tidak", "T", JFrame.EXIT_ON_CLOSE);
					clean();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal ditambah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
					}
				}	
			}
		});
		btnTambah.setForeground(Color.WHITE);
		btnTambah.setBackground(Color.RED);
		btnTambah.setBounds(24, 402, 96, 25);
		contentPane.add(btnTambah);

		btnUbah = new JButton("Ubah");
		btnUbah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "UPDATE Punya_Aturan_Tidak SET Satu  = ?, Dua  = ? WHERE IdAturanTidak = ? ";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);
					prepare.setString(1,
							(String) cmbIdGejala1.getSelectedItem());
					prepare.setString(2,
							(String) cmbIdGejala2.getSelectedItem());
					prepare.setString(3, txtAturanYa.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data berhasil diubah",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					// txtIdKerusakan.setText("");
					// txtNo.setText("");
					tampilTabel();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
					autoNomer("Punya_Aturan_Tidak", "T", JFrame.EXIT_ON_CLOSE);
					clean();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal diubah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
				}
			}
		});
		btnUbah.setForeground(Color.WHITE);
		btnUbah.setBackground(Color.RED);
		btnUbah.setEnabled(false);
		btnUbah.setBounds(116, 402, 96, 25);
		contentPane.add(btnUbah);

		btnHapus = new JButton("Hapus");
		btnHapus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "DELETE FROM Punya_Aturan_Tidak WHERE IdAturanTidak = ?";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtAturanYa.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil dihapus", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					clean();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
					autoNomer("Punya_Aturan_Tidak", "T", JFrame.EXIT_ON_CLOSE);
				} catch (Exception ex) {
					System.out.println(ex);
				}
			}
		});
		btnHapus.setForeground(Color.WHITE);
		btnHapus.setBackground(Color.RED);
		btnHapus.setEnabled(false);
		btnHapus.setBounds(208, 402, 96, 25);
		contentPane.add(btnHapus);

		btnKeluar = new JButton("Keluar");
		btnKeluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Keluar();
			}
		});
		btnKeluar.setForeground(Color.WHITE);
		btnKeluar.setBackground(Color.RED);
		btnKeluar.setBounds(386, 402, 96, 25);
		contentPane.add(btnKeluar);

		lblIdGejala1 = new JLabel("Id Gejala 1 :");
		lblIdGejala1.setBounds(24, 125, 126, 15);
		contentPane.add(lblIdGejala1);

		lblNmGejala = new JLabel("Nama Gejala :");
		lblNmGejala.setBounds(267, 121, 126, 15);
		contentPane.add(lblNmGejala);

		txtNmGejala1 = new JTextField();
		txtNmGejala1.setEnabled(false);
		txtNmGejala1.setColumns(10);
		txtNmGejala1.setBounds(403, 115, 134, 25);
		contentPane.add(txtNmGejala1);

		lblNmGejala2 = new JLabel("Nama Gejala :");
		lblNmGejala2.setBounds(267, 154, 146, 15);
		contentPane.add(lblNmGejala2);

		txtNmGejala2 = new JTextField();
		txtNmGejala2.setEnabled(false);
		txtNmGejala2.setColumns(10);
		txtNmGejala2.setBounds(403, 154, 134, 19);
		contentPane.add(txtNmGejala2);

		cmbIdGejala1 = new JComboBox();
		cmbIdGejala1.setModel(new DefaultComboBoxModel(new String[] {"--Pilih--"}));
		cmbIdGejala1.setBackground(Color.WHITE);
		cmbIdGejala1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String nmgejala = "";
					//Connection con = (Connection) Koneksi.getKoneksi();
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost/dbsispaktoyota",
					"root","root");
					//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
						//	"root","root");
					Statement state = con.createStatement();
					String sql = "select NmGejala from Gejala where IdGejala = '"
							+ cmbIdGejala1.getSelectedItem() + "'";
					ResultSet rs = state.executeQuery(sql);
					while (rs.next()) {
						nmgejala = rs.getString("NmGejala");
					}
					txtNmGejala1.setText(nmgejala);
					rs.close();
					con.close();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null,
							"data tidak teridentifikasi", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		cmbIdGejala1.setBounds(135, 118, 126, 22);
		contentPane.add(cmbIdGejala1);

		cmbIdGejala2 = new JComboBox();
		cmbIdGejala2.setModel(new DefaultComboBoxModel(new String[] {"--Pilih--"}));
		cmbIdGejala2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String nmkerusakan = "";
					//Connection con = (Connection) Koneksi.getKoneksi();
					String nmgejala = "";			
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost/dbsispaktoyota",
					"root","root");
					//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
						//	"root","root");
					Statement state = con.createStatement();
					String sql = "select NmGejala from Gejala where IdGejala = '"
							+ cmbIdGejala2.getSelectedItem() + "'";
					ResultSet rs = state.executeQuery(sql);
					while (rs.next()) {
						nmkerusakan = rs.getString("NmGejala");
					}
					txtNmGejala2.setText(nmkerusakan);
					rs.close();
					con.close();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null,
							"data tidak teridentifikasi", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		cmbIdGejala2.setBackground(Color.WHITE);
		cmbIdGejala2.setBounds(135, 149, 126, 22);
		contentPane.add(cmbIdGejala2);

		IdAturanTidak = new JLabel("Id AturanTdk :");
		IdAturanTidak.setBounds(24, 96, 126, 15);
		contentPane.add(IdAturanTidak);

		txtAturanYa = new JTextField();
		txtAturanYa.setEnabled(false);
		txtAturanYa.setColumns(10);
		txtAturanYa.setBounds(135, 94, 134, 19);
		contentPane.add(txtAturanYa);
		
		lblCari = new JLabel("Cari Aturan Tidak :");
		lblCari.setBounds(24, 371, 134, 15);
		contentPane.add(lblCari);
		
		txtCari = new JTextField();
		txtCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariAturanTidak();
			}
		});
		txtCari.setColumns(10);
		txtCari.setBounds(163, 371, 275, 19);
		contentPane.add(txtCari);
		
		btnCari = new JButton("");
		btnCari.setIcon(new ImageIcon(FrmAturanTidak.class.getResource("/image/system-search.png")));
		btnCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariAturanTidak();
			}
		});
		btnCari.setForeground(Color.WHITE);
		btnCari.setBackground(new Color(0, 204, 255));
		btnCari.setBounds(445, 368, 23, 23);
		contentPane.add(btnCari);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(0, 66, 547, 10);
		contentPane.add(panel_1);
		setLocationRelativeTo(null);

		tampilTabel();
		cariIDGejala1();
		cariIDGejala2();
		autoNomer("Punya_Aturan_Tidak", "T", JFrame.EXIT_ON_CLOSE);
		// autonumber();
	}

	void cariAturanTidak(){
		try{
			/*Class.forName("com.mysql.jdbc.Driver").newInstance();	
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/sistempakar", "root", "root");*/
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String sql = "select * from IdAturanTidak where IdAturanTidak like '%" + txtCari.getText()+ "%'";
			ResultSet rs = state.executeQuery(sql);
			while (rs.next()) {
			tabelModel.addRow(new Object[]{
			rs.getString(1),
			rs.getString(2),
			rs.getString(3)
			});
			}
			table.setModel(tabelModel);
			//tampilTabel();
			txtCari.setText("");
			}catch (Exception e){
				System.out.println(e);
			}
			}
	
	void cariIDGejala1() {
		try {

			//Connection con = (Connection) Koneksi.getKoneksi();
			String nmgejala = "";			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/dbsispaktoyota",
			"root","root");
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			Statement st = con.createStatement();
			String sql = "select * from Gejala";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				cmbIdGejala1.addItem(rs.getString(1));
			}
			st.close();
			con.close();
		} catch (Exception ex) {
			System.out.println("tak terdeteksi");
		}
	}

	void cariIDGejala2() {
		try {
			//Connection conek = (Connection) Koneksi.getKoneksi();
			String nmgejala = "";			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/dbsispaktoyota",
			"root","root");
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			Statement st = con.createStatement();
			String sql = "select * from Gejala";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				cmbIdGejala2.addItem(rs.getString(1));
			}
			st.close();
			con.close();
		} catch (Exception ex) {
			System.out.println("tak terdeteksi");
		}
	}

	public String autoNomer(String tabel, String strAwal, Integer pnj) {
		String auto = "";
		String s, s1;
		Integer j;
		try {
			//Connection con = (Connection) Koneksi.getKoneksi();
			String nmgejala = "";			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/dbsispaktoyota",
			"root","root");
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			java.sql.Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from " + tabel);
			rs.last();

			s = Integer.toString(rs.getRow() + 1);
			j = s.length();
			s1 = "";
			for (int i = 1; i <= pnj - j; i++) {
				s1 = s1 + "0";
			}
			rs.close();
			stat.close();
			auto = strAwal + s1 + s;
			txtAturanYa.setText(auto);

		} catch (Exception e) {
			System.out.println("Pesan Error : " + e);
			JOptionPane.showMessageDialog(null,
					"Maaf, Query tidak bisa dijalankan...!!!!");
		}
		return auto;
	}

	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String query = "SELECT * FROM Punya_Aturan_Tidak";
			ResultSet rs = state.executeQuery(query);
			while (rs.next()) {

				Object obj[] = new Object[3];
				obj[0] = rs.getString(1);
				obj[1] = rs.getString(2);
				obj[2] = rs.getString(3);
				tabelModel.addRow(obj);
				sesuaikanKolom();
			}
			rs.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);

		}
	}

	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}

	void clean() {
		cmbIdGejala1.setSelectedIndex(0);
		cmbIdGejala2.setSelectedIndex(0);
	}
}
