/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Menu Pemakai
 * Nama Fie		: FrmMenuPemakai.java
 ======================================================================= 
 */
package sispakmobiltoyota;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import IconMakeOver.IconLabel;
import IconMakeOver.IconBayang;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;

public class FrmMenuPemakai extends JFrame {

	private JPanel contentPane;
	private JPanel panel;
	private JLabel label_1;
	private JLabel lblAnugrah;
	private JPanel panel_1;
	private IconLabel lblDiagnosa;
	private IconLabel lblBantuan;
	private IconLabel lblKembali;
	private JLabel lblpengaturan;
	private static JLabel lbllogin;
	private IconLabel lblKamus;
	private JLabel label_2;
	private JLabel lblBlackberryBoldTouch;
	private JLabel lblBerbasisClientserver;

	// FrmLogin login = new FrmLogin();

	/**
	 * Launch the application.
	 */
	
	  /*public static void main(String[] args) { EventQueue.invokeLater(new
	  Runnable() { public void run() { try { FrmMenuPemakai frame = new
	  FrmMenuPemakai(); frame.setVisible(true); } catch (Exception e) {
	  e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmMenuPemakai() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmMenuPemakai.class.getResource("/image/icon100x100.png")));
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 735, 456);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		/*
		 * login = new FrmLogin(); login.setVisible(true);
		 */

		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, -11, 733, 116);
		contentPane.add(panel);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(FrmMenuPemakai.class.getResource("/image/icon100x100.png")));
		label.setBounds(12, 0, 140, 129);
		panel.add(label);

		label_1 = new JLabel("Selamat Datang di");
		label_1.setForeground(Color.RED);
		label_1.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 10));
		label_1.setBounds(156, 18, 295, 32);
		panel.add(label_1);
		
		label_2 = new JLabel("Sistem Pakar untuk Mengidentifikasi Kerusakan");
		label_2.setForeground(Color.RED);
		label_2.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		label_2.setBounds(156, 41, 472, 18);
		panel.add(label_2);
		
		lblBlackberryBoldTouch = new JLabel("Mobil Toyota Great Corolla dengan Metode Backward Chaining");
		lblBlackberryBoldTouch.setForeground(Color.RED);
		lblBlackberryBoldTouch.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblBlackberryBoldTouch.setBounds(156, 62, 527, 18);
		panel.add(lblBlackberryBoldTouch);
		
		lblBerbasisClientserver = new JLabel("Berbasis Client-Server");
		lblBerbasisClientserver.setForeground(Color.RED);
		lblBerbasisClientserver.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblBerbasisClientserver.setBounds(156, 86, 458, 18);
		panel.add(lblBerbasisClientserver);

		panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.RED);
		panel_1.setBounds(0, 393, 733, 31);
		contentPane.add(panel_1);

		lblAnugrah = new JLabel("1111530109 - ADITYA WIRAWAN");
		lblAnugrah.setBounds(0, 0, 733, 31);
		panel_1.add(lblAnugrah);
		lblAnugrah.setHorizontalTextPosition(SwingConstants.LEADING);
		lblAnugrah.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnugrah.setForeground(Color.WHITE);
		lblAnugrah.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 10));

		lblDiagnosa = new IconLabel();
		lblDiagnosa.setForeground(new Color(255, 255, 255));
		lblDiagnosa.setIconReflect(new ImageIcon(FrmMenuPemakai.class.getResource("/image/search.png")));
		lblDiagnosa.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new FrmPilihKerusakan().show();
			}
		});
		lblDiagnosa.setText("Diagnosa");
		lblDiagnosa.setBounds(75, 165, 100, 197);
		contentPane.add(lblDiagnosa);

		lblBantuan = new IconLabel();
		lblBantuan.setForeground(new Color(255, 255, 255));
		lblBantuan.setIconReflect(new ImageIcon(FrmMenuPemakai.class.getResource("/image/dialog-question.png")));
		lblBantuan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmBantuan bantuan = new FrmBantuan();
				bantuan.setVisible(true);
			}
		});
		lblBantuan.setText("Bantuan");
		lblBantuan.setBounds(356, 171, 106, 184);
		contentPane.add(lblBantuan);

		lblKembali = new IconLabel();
		lblKembali.setForeground(new Color(255, 255, 255));
		lblKembali.setIconReflect(new ImageIcon(FrmMenuPemakai.class.getResource("/image/chrome-eoieeedlomnegifmaghhjnghhmcldobl-Default.png")));
		lblKembali.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Keluar();
				//new Homescreen().show();
			}
		});
		lblKembali.setText("Kembali");
		lblKembali.setBounds(502, 166, 100, 189);
		contentPane.add(lblKembali);

		lblpengaturan = new JLabel("--MENU PEMAKAI--");
		lblpengaturan.setForeground(new Color(255, 255, 255));
		lblpengaturan.setFont(new Font("Dialog", Font.BOLD, 16));
		lblpengaturan.setHorizontalTextPosition(SwingConstants.CENTER);
		lblpengaturan.setBounds(247, 144, 224, 15);
		contentPane.add(lblpengaturan);

		lbllogin = new JLabel("");
		lbllogin.setBounds(65, 375, 70, 15);
		contentPane.add(lbllogin);

		lblKamus = new IconLabel();
		lblKamus.setForeground(new Color(255, 255, 255));
		lblKamus.setIconReflect(new ImageIcon(FrmMenuPemakai.class.getResource("/image/alacarte.png")));
		lblKamus.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmKamusPemakai kamus = new FrmKamusPemakai();
				kamus.show(true);
			}
		});
		lblKamus.setText("Kamus");
		lblKamus.setBounds(206, 172, 106, 184);
		contentPane.add(lblKamus);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 103, 733, 10);
		contentPane.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 385, 733, 15);
		contentPane.add(panel_3);

		// statusLogin();

	} // akhir konstruktor
	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				new Homescreen().show();
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}
}
